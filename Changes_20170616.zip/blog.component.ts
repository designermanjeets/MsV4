import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../_services/index';

@Component({
    moduleId: module.id,
    templateUrl: 'blog.component.html',
    styleUrls: ['./blog.component.css']
})

export class BlogComponent {
    blog: any = {};
    isPosting:any;
    postListings:any;
    isPublish:any;
    bloglisting= [];

    constructor(private userService: UserService){}

    ngOnInit() {
        this.getAllBlogsOnLoad();
    }

    //Create Blog API Call
     postSubmit() {
        this.userService.publishBlog(this.blog)
            .subscribe(
                data => {
                    console.log(data);
                    this.postListings = true;
                    this.isPosting = false;
                    this.isPublish = false;
                    this.bloglisting.push(data);
                },
                error => {
                    console.log(error);
                });
    }

    //Retrieve All Blogs API Call
    private getAllBlogsOnLoad(): void {
        this.userService.getAllBlogs()
            .subscribe(
                data => {
                    this.bloglisting = data[0].articles;
                },
                error => {
                    console.log(error);
                });
    }
}